package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.annotation.SuppressLint;
import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

@SuppressLint("SetTextI18n")
public class MainActivity extends AppCompatActivity {
    //CLIENT
    Thread Thread1 = null;
    EditText etIP, etPort;
    TextView tvMessages;
    EditText etMessage;
    Button btnSend;
    String SERVER_IP;
    int SERVER_PORT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etIP = findViewById(R.id.etIP);
        etPort = findViewById(R.id.etPort);
        tvMessages = findViewById(R.id.tvMessages);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);
        Button btnConnect = findViewById(R.id.btnConnect);
        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvMessages.setText("");
                SERVER_IP = etIP.getText().toString().trim();
                SERVER_PORT = Integer.parseInt(etPort.getText().toString().trim());
                Thread1 = new Thread(new Thread1());
                Thread1.start();
            }
        });
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = etMessage.getText().toString().trim();
                if (!message.isEmpty()) {
                    new Thread(new Thread3(message)).start();
                }
            }
        });
    }
    DataInputStream input = null;
    DataOutputStream output = null;

    class Thread1 implements Runnable {
        @Override
        public void run() {
            Socket socket;
            try {

                socket = new Socket(SERVER_IP, SERVER_PORT);
                output = new DataOutputStream(socket.getOutputStream());

                input = new DataInputStream((socket.getInputStream()));

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvMessages.setText("Connected ");
                    }
                });
                new Thread(new Thread2()).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class Thread2 implements Runnable {


        int j = 0;
        Socket socket;

        FileWriter fw;
byte b[]=new byte[4000000];
        @Override
        public void run() {
            while (true) {
                try {
                    fw = new FileWriter("/sdcard/temperature.txt");
                    //from get input in string













                   int j = input.read(b,0,4000000);
                   fw.write(new String(b));
                   fw.write("1");
                   fw.close();
                  /* if (message != null) {
                      runOnUiThread(new Runnable() {
                          @Override
                          public void run() {
                              tvMessages.setText("server: " + j + message + " ");
                              j++;
                         }
                      });*/
                  split();
                    } catch (IOException e) {
                    e.printStackTrace();
                }


            }

            }
        }

int rw=0;
    int count=0;
    void split() {
        try {
            byte b[] = new byte[400000];
            int x = 1, y = 0;
            String s = "";
            // InputStreamReader ins = new InputStreamReader(System.in);
            //BufferedReader br = new BufferedReader(ins);

            //System.out.println("Enter path of the file ");
            //String path = br.readLine();
            String path = "/sdcard/temperature.txt";
            FileInputStream fis = new FileInputStream(path);
            int read_bytes;
            while (fis.available() != 0) {
                y = 0;
                s = "";

                s = "/sdcard/" + x + ".txt";

                FileOutputStream fos = new FileOutputStream(s);

                while (y <= 5000 && fis.available() != 0) {
                    read_bytes = fis.read(b, 0, 400000);
                    y = y + read_bytes;
                    fos.write(b, 0, read_bytes);
                }
                fos.close();
                //System.out.println("Part "+x+" created.");
                x++;
            }

            // System.out.println("File splitted successfully.");
            fis.close();

            //searching
            searching search[]=new searching[x];
           for(int i=0;i<x;i++)
           {
               search[i]=new searching("/sdcard/"+(i+1)+".txt");
               search[i].start();

           }
            for(int i=0;i<x;i++)
            {

                search[i].join();
            }

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tvMessages.setText("\nclient: "+ count + " ");
                    rw++;

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    class searching extends Thread {

        String path;

        searching(String p)
        {
            path=p;
        }


@Override
       public void run() {
            try {

                String s = "", g;
                FileReader rdr = new FileReader(path);
                BufferedReader br = new BufferedReader(rdr);
                //Toast.makeText( "There is file to read data. ", Toast.LENGTH_SHORT).show();
                //BufferedReader br=new BufferedReader(rdr);

                //  char[] inputBuffer = new char[1024];//get Block size as buffer
                // String s = "",g;
                int i = 0, j = 0;
                tvMessages.setText("");
                while ((g = br.readLine()) != null) {
                    //j++;
                    //((TextView) findViewById(R.id.tv2)).setText(String.valueOf(j));
                    //s+="\n"+g;
                    if (g.equals("20")) {
                        //tvMessages.append(g);
                        count++;
                    }
                    // j++;
                }

                //((TextView) findViewById(R.id.text1)).setText(String.valueOf(count));
                // ((TextView) findViewById(R.id.tv1)).setText(String.valueOf(i));
                //int charRead = rdr.read(inputBuffer);
                //Read all data one by one by using loop and add it to string created above
                // for (int k = 0; k < charRead; k++) {
                //   savedData += inputBuffer[k];
                //}
                // Data is displayed in the TextView
                // ((TextView) findViewById(R.id.tv2)).setText(s);
                br.close();
                //isr.close();
                rdr.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
}



    class Thread3 implements Runnable {

        private String message;
        Thread3(String message) {
            this.message = message;
        }

        @Override
        public void run() {
            try {
               // output.writeUTF(message);
            } catch (Exception e) {
                e.printStackTrace();
            }

            runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvMessages.append("client: " + message + " ");
                        etMessage.setText("");
                    }
                });
                try {


                    //output.flush();
                }
                catch(Exception e)
                {

                }
            }

    }
}